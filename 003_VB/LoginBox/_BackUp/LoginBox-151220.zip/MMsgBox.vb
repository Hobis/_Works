﻿Imports System
Imports System.Runtime.InteropServices
Imports System.Windows.Forms
Imports System.Threading

Public Module MMsgBox

    Private Enum _HookType As Integer
        WH_CBT = 5
    End Enum

    Private Delegate Function _HookProc(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As Integer

    <DllImportAttribute("user32.dll", _
        EntryPoint:="GetCurrentThreadId", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Public Function p_GetCurrentThreadId() As Integer
    End Function

    <DllImportAttribute("user32.dll", _
        EntryPoint:="SetWindowsHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_SetWindowsHookEx(hookType As _HookType, lpfn As _HookProc, hMod As IntPtr, dwThreadId As UInteger) As IntPtr
    End Function

    <DllImportAttribute("user32.dll", _
        EntryPoint:="UnhookWindowsHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_UnhookWindowsHookEx(hHook As IntPtr) As Boolean
    End Function

    <DllImportAttribute("user32.dll", _
        EntryPoint:="CallNextHookEx", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_CallNextHookEx(hHook As IntPtr, nCode As Integer, wParam As IntPtr, lParam As IntPtr) As IntPtr
    End Function




    <StructLayout(LayoutKind.Sequential)> _
    Private Structure _Rect
        Public Left As Integer
        Public Top As Integer
        Public Right As Integer
        Public Bottom As Integer
        '
        Public Overrides Function ToString() As String
            Dim t_rv As String = _
                "Left=" & Me.Left & ", " &
                "Top=" & Me.Top & ", " &
                "Right=" & Me.Right & ", " &
                "Bottom=" & Me.Bottom
            Return t_rv
        End Function
    End Structure

    ' ::
    <DllImport("user32.dll", _
        EntryPoint:="GetWindowRect", _
        CharSet:=CharSet.Auto,
        CallingConvention:=CallingConvention.StdCall, _
        SetLastError:=True)> _
    Private Function p_GetWindowRect(hWnd As IntPtr, lpRect As _Rect) As Boolean
    End Function



    Public Function Show(owner As IWin32Window, msg As String, title As String) As DialogResult
        _HookProcDelegate = AddressOf p_HookProc
        _msg = msg
        _caption = title
        _hHook = p_SetWindowsHookEx(_HookType.WH_CBT, _HookProcDelegate, IntPtr.Zero, p_GetCurrentThreadId())
        '
        MessageBox.Show(owner, _msg, _caption)
        '
        Return Nothing
    End Function



    Private _HookProcDelegate As _HookProc = Nothing
    Private _hHook As IntPtr = IntPtr.Zero
    Private _msg As String = Nothing
    Private _caption As String = Nothing


    Private Function p_HookProc(nCode As Integer, wParam As IntPtr, lParam As IntPtr) As Integer
        Return 0
    End Function





End Module
