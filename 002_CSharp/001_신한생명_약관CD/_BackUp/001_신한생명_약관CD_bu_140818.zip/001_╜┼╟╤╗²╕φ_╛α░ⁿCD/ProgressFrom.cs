﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace NewEdge_002
{
    public sealed partial class ProgressFrom : Form
    {
        public ProgressFrom()
        {
            InitializeComponent();
        }

        // ::
        private void p_ProgressFrom_Load(object sender, EventArgs ea)
        {
            //this.
        }
    }
}
