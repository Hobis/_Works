﻿using System;
using System.IO;
using System.Text;
using System.Threading;


namespace HobisTools.Koster
{
    // #
    public enum TypeTo
    {
        None,
        BinaryDataToBase64String,
        Base64StringToBinaryData
    }

    // #
    public enum CallBackType
    {
        WorkEnd
    }

    // #
    internal static class IOUtils
    {
        public static void StreamDispose(IDisposable ido)
        {
            if (ido != null)
            {
                ido.Dispose();
            }
        }
    }

    // #
    public static class Debug
    {
        public static void Log(string msg)
        {
            Console.WriteLine("# [hb] " + msg);
        }
    }

    // #
    public static class TWorker
    {
        //-
        private static TypeTo _type = TypeTo.None;
        // -
        private static Action<object[]> _callBack = null;
        // -
        private static Thread _th = null;
        // -
        private static string[] _fps = null;

        // -
        private const int _Delay = 100;
        // -
        private const string _ExeName_base64 = ".base64str";


        // ::
        public static void Stop()
        {
            _th = null;
        }

        // ::
        public static void Start(string[] fps, TypeTo type, Action<object[]> callBack)
        {
            if (fps == null) return;

            if (_th == null)
            {
                _fps = fps;
                _type = type;
                _callBack = callBack;

                _th = new Thread(new ThreadStart(p_Work));
                _th.Start();
            }
        }

        // ::
        private static void p_Work()
        {
            foreach (string t_fp in _fps)
            {
                if (_th == null)
                {
                    //
                    break;
                }
                else
                {
                    // 파일이 있으면
                    if (File.Exists(t_fp))
                    {
                        switch (_type)
                        {
                            // 
                            case TypeTo.BinaryDataToBase64String:
                                {
                                    if (new FileInfo(t_fp).Extension.Equals(_ExeName_base64))
                                    {
                                    }
                                    else
                                    {
                                        // 읽기전용 스트림
                                        FileStream t_rfs = null;

                                        // 쓰기전용 스트림
                                        FileStream t_wfs = null;

                                        try
                                        {
                                            t_rfs = File.OpenRead(t_fp);
                                        }
                                        catch (Exception) {}

                                        try
                                        {
                                            t_wfs = File.OpenWrite(t_fp + _ExeName_base64);
                                        }
                                        catch (Exception) {}

                                        //Debug.Log("t_rfs: " + t_rfs);
                                        //Debug.Log("t_wfs: " + t_wfs);
                                        if
                                        (
                                            (t_rfs != null) &&
                                            (t_wfs != null)
                                        )
                                        {
                                            StreamWriter t_sw = new StreamWriter(t_wfs);
                                            byte[] t_buffer = new byte[1024 * 32];
                                            while (t_rfs.Read(t_buffer, 0, t_buffer.Length) > 0)
                                            {
                                                t_sw.Write(Convert.ToBase64String(t_buffer));
                                                // CPU 점유율 낮추기 위해서 딜레이
                                                //Thread.Sleep(_Delay);                                                
                                            }
                                            IOUtils.StreamDispose(t_sw);
                                        }

                                        //
                                        IOUtils.StreamDispose(t_rfs);
                                        IOUtils.StreamDispose(t_wfs);
                                    }

                                    break;
                                }

                            // 
                            case TypeTo.Base64StringToBinaryData:
                                {
                                    //
                                    break;
                                }
                        }

                        //
                        Thread.Sleep(_Delay);
                    }
                }
            }

            _callBack(new object[] {CallBackType.WorkEnd});
            //
            p_Clear();
        }

        // ::
        private static void p_Clear()
        {
            if (_th != null)
            {
                _type = TypeTo.None;
                _callBack = null;
                _fps = null;

                _th = null;
            }
        }
    }
}
