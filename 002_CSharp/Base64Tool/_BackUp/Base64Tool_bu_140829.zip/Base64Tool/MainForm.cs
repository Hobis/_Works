﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace HobisTools.Koster
{
    // #
    public partial class MainForm : Form
    {
        // ::
        public MainForm()
        {
            InitializeComponent();
        }

        // ::
        private void p_This_Load(object sender, EventArgs ea)
        {
            this.Text += " Ver 1.02 Programed By HobisJung";

            this.textBox_1.AllowDrop = true;
            this.textBox_1.DragEnter += this.p_textBox_1_DragEnter;
            this.textBox_1.DragDrop += this.p_textBox_1_DragDrop;

        }

        // ::
        private void p_textBox_1_DragEnter(object sender, DragEventArgs dea)
        {
            if (dea.Data.GetDataPresent(DataFormats.FileDrop))
            {
                dea.Effect = DragDropEffects.Copy;
            }
            else
            {
                dea.Effect = DragDropEffects.None;
            }
        }

        // ::
        private void p_textBox_1_DragDrop(object sender, DragEventArgs dea)
        {
            string[] t_fns = (string[])dea.Data.GetData(DataFormats.FileDrop);
            if (t_fns != null)
            {
                StringBuilder t_sb = new StringBuilder();

                foreach (string t_fn in t_fns)
                {
                    string t_nfn = t_fn;
                    if (t_nfn != null)
                    {
                        t_sb.AppendLine(t_nfn);
                    }
                }

                this.textBox_1.AppendText(t_sb.ToString());
            }
        }

        // ::
        private void p_button_1_Click(object sender, EventArgs ea)
        {
            byte[] t_bytes = Convert.
                FromBase64String(this.textBox_1.Text);

            //byte[] t_bytes = Convert.FromBase64String(this.textBox1.Text);
            File.WriteAllBytes("Temp.png", t_bytes);
            //this.textBox1.Text
        }



/*
        public static string Base64Encode(string src, System.Text.Encoding enc)
        {
            byte[] arr = enc.GetBytes(src);
            return Convert.ToBase64String(arr);
        }

        public static string Base64Decode(string src, System.Text.Encoding enc)
        {
            byte[] arr = Convert.FromBase64String(src);
            return enc.GetString(arr);
        }  */
    }
}
